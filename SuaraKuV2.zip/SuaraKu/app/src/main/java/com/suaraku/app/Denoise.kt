package com.suaraku.app

import kotlin.math.*

class Fft(private val n: Int) {
    private val cs = DoubleArray(n / 2) { cos(2 * PI * it / n) }
    private val sn = DoubleArray(n / 2) { -sin(2 * PI * it / n) }
    private val rev = IntArray(n).also {
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) it[i] = Integer.reverse(i) ushr (32 - bits)
    }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cs[k]
                    val wi = if (inverse) -sn[k] else sn[k]
                    val tr = re[j + half] * wr - im[j + half] * wi
                    val ti = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - tr; im[j + half] = im[j] - ti
                    re[j] += tr; im[j] += ti
                    k += step
                }
                i += size
            }
            size *= 2
        }
        if (inverse) for (i in 0 until n) { re[i] /= n; im[i] /= n }
    }
}

/** Penghilang noise spektral (in-place). Profil noise diambil dari bagian paling sunyi.
 *  Gain dihaluskan di waktu dan frekuensi + lantai gain, supaya suara tetap jernih dan tanpa "musical noise". */
object Denoise {
    private const val N = 2048
    private const val HOP = 512

    fun run(x: FloatArray, level: Int, check: () -> Unit) {
        if (x.size < N * 4) return
        val alpha = doubleArrayOf(1.2, 1.6, 2.2)[level - 1]
        val gmin = 10.0.pow(-doubleArrayOf(8.0, 14.0, 20.0)[level - 1] / 20.0)
        val fft = Fft(N)
        val w = DoubleArray(N) { sqrt(0.5 - 0.5 * cos(2 * PI * it / N)) }
        val bins = N / 2 + 1
        val re = DoubleArray(N)
        val im = DoubleArray(N)

        // 1. Profil noise dari 10% frame paling sunyi
        val frames = (x.size - N) / HOP + 1
        val en = DoubleArray(frames)
        for (t in 0 until frames) {
            var s = 0.0
            val o = t * HOP
            for (i in 0 until N) { val v = x[o + i].toDouble(); s += v * v }
            en[t] = s
        }
        val sorted = en.copyOf().also { it.sort() }
        val thr = sorted[(frames * 0.10).toInt().coerceIn(0, frames - 1)]
        val picks = ArrayList<Int>()
        for (t in 0 until frames) if (en[t] <= thr && en[t] > 1e-9) picks.add(t)
        if (picks.size < 5) return
        val step = max(1, picks.size / 300)
        val noise = DoubleArray(bins)
        var cnt = 0
        var pi = 0
        while (pi < picks.size) {
            val o = picks[pi] * HOP
            for (i in 0 until N) { re[i] = x[o + i] * w[i]; im[i] = 0.0 }
            fft.transform(re, im, false)
            for (k in 0 until bins) noise[k] += re[k] * re[k] + im[k] * im[k]
            cnt++
            pi += step
        }
        for (k in 0 until bins) noise[k] /= cnt
        val ns = DoubleArray(bins)
        for (k in 0 until bins) {
            var s = 0.0; var c = 0
            for (j in max(0, k - 3)..min(bins - 1, k + 3)) { s += noise[j]; c++ }
            ns[k] = s / c
        }

        // 2. Proses utama (in-place, overlap-add 75%)
        val prevG = DoubleArray(bins) { 1.0 }
        val g = DoubleArray(bins)
        val gs = DoubleArray(bins)
        val acc = DoubleArray(N)
        var t = 0
        while (true) {
            val start = t * HOP - (N - HOP)
            if (start >= x.size) break
            if (t % 200 == 0) check()
            for (i in 0 until N) {
                val p = start + i
                re[i] = if (p >= 0 && p < x.size) x[p] * w[i] else 0.0
                im[i] = 0.0
            }
            fft.transform(re, im, false)
            for (k in 0 until bins) {
                val p = re[k] * re[k] + im[k] * im[k] + 1e-12
                var gk = sqrt(max(gmin * gmin, 1.0 - alpha * ns[k] / p))
                gk = if (gk > prevG[k]) prevG[k] + 0.7 * (gk - prevG[k]) else prevG[k] + 0.25 * (gk - prevG[k])
                prevG[k] = gk
                g[k] = gk
            }
            for (k in 0 until bins) gs[k] = (g[max(0, k - 1)] + 2 * g[k] + g[min(bins - 1, k + 1)]) / 4
            for (k in 0 until bins) {
                re[k] *= gs[k]; im[k] *= gs[k]
                if (k in 1 until N / 2) { re[N - k] *= gs[k]; im[N - k] *= gs[k] }
            }
            fft.transform(re, im, true)
            for (i in 0 until N) acc[i] += re[i] * w[i] * 0.5
            for (i in 0 until HOP) {
                val p = start + i
                if (p >= 0 && p < x.size) x[p] = acc[i].toFloat()
            }
            System.arraycopy(acc, HOP, acc, 0, N - HOP)
            java.util.Arrays.fill(acc, N - HOP, N, 0.0)
            t++
        }
    }
}

/** Pengurang suara napas: segmen 180 ms - 1,2 dtk yang pelan, tak bernada (bukan vokal), dan jauh di bawah level bicara.
 *  Tidak dihapus total, hanya diredam dengan transisi halus supaya terdengar natural. */
object Breath {
    fun run(x: FloatArray, rate: Int, level: Int) {
        val fl = rate / 100
        val n = x.size / fl
        if (n < 100) return
        val db = DoubleArray(n)
        for (i in 0 until n) {
            var s = 0.0
            val o = i * fl
            for (k in 0 until fl) { val v = x[o + k].toDouble(); s += v * v }
            db[i] = 10 * log10(s / fl + 1e-10)
        }
        val sorted = db.copyOf().also { it.sort() }
        val noise = max(sorted[(n * 0.10).toInt()], -80.0)
        val speech = sorted[(n * 0.90).toInt().coerceAtMost(n - 1)]
        if (speech - noise < 20) return
        val g = 10.0.pow(-doubleArrayOf(10.0, 18.0, 28.0)[level - 1] / 20.0)

        val cand = BooleanArray(n)
        for (i in 0 until n) cand[i] = db[i] > noise + 5 && db[i] < speech - 12 && !voiced(x, i * fl, fl)

        val runs = ArrayList<IntArray>()
        var s = -1
        var last = -1
        for (i in 0 until n) {
            if (cand[i]) { if (s < 0) s = i; last = i }
            else if (s >= 0 && i - last > 3) {
                if (last - s + 1 in 18..120) runs.add(intArrayOf(s, last + 1))
                s = -1
            }
        }
        if (s >= 0 && last - s + 1 in 18..120) runs.add(intArrayOf(s, last + 1))

        val ramp = rate * 30 / 1000
        for (r in runs) {
            val a = r[0] * fl
            val b = min(x.size, r[1] * fl)
            for (p in a until b) {
                val d = min(p - a, b - 1 - p)
                val m = if (d >= ramp) 1.0 else 0.5 - 0.5 * cos(PI * d / ramp)
                x[p] = (x[p] * (1.0 - (1.0 - g) * m)).toFloat()
            }
        }
    }

    /** Deteksi bernada lewat autokorelasi (di-decimate 4x). */
    private fun voiced(x: FloatArray, o: Int, fl: Int): Boolean {
        val len = fl * 3
        val start = max(0, o - fl)
        if (start + len > x.size) return true
        val m = len / 4
        val d = DoubleArray(m) { j ->
            var s = 0.0
            for (k in 0 until 4) s += x[start + j * 4 + k]
            s / 4
        }
        var e0 = 0.0
        for (v in d) e0 += v * v
        if (e0 < 1e-12) return false
        val dr = 11025.0
        val lagMin = (dr / 450).toInt()
        val lagMax = min((dr / 70).toInt(), m / 2)
        var best = 0.0
        for (l in lagMin..lagMax) {
            var c = 0.0; var e1 = 0.0; var e2 = 0.0
            for (j in 0 until m - l) { c += d[j] * d[j + l]; e1 += d[j] * d[j]; e2 += d[j + l] * d[j + l] }
            val r = c / sqrt(e1 * e2 + 1e-18)
            if (r > best) best = r
        }
        return best > 0.5
    }
}
