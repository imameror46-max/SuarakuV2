package com.suaraku.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/** Karakter suara: f0 = nada target (Hz, 0 = tidak diubah), formant = ukuran saluran suara absolut
 *  (laki-laki dewasa = 1.0, perempuan dewasa = 1.17, anak = 1.35), speed = kecepatan. */
data class Effect(val name: String, val f0: Double, val formant: Double, val speed: Double) {
    val isOriginal get() = f0 <= 0.0 && speed == 1.0
}

/** Gaya intonasi. std = sebaran nada target (semiton), tilt = turun nada sepanjang frasa,
 *  fall = turun nada di akhir frasa, smooth = penghalusan (frame 5 ms), pause = skala jeda. */
data class Style(
    val name: String, val std: Double, val tilt: Double, val fall: Double, val smooth: Int,
    val pause: Double, val speed: Double, val pitchMul: Double, val formantMul: Double,
    val warm: Double, val comp: Boolean
) {
    val isNone get() = name == "Tanpa"
}

enum class OutFmt(val label: String, val ext: String) { WAV("WAV", "wav"), M4A("M4A", "m4a") }

val EFFECTS = listOf(
    Effect("Asli", 0.0, 1.0, 1.0),
    Effect("Laki-laki", 118.0, 1.0, 1.0),
    Effect("Perempuan", 205.0, 1.17, 1.0),
    Effect("Anak Kecil", 270.0, 1.35, 1.03),
    Effect("Bayi", 330.0, 1.5, 1.08),
    Effect("Tupai", 400.0, 1.6, 1.2),
    Effect("Kakek", 100.0, 0.97, 0.9),
    Effect("Raksasa", 70.0, 0.8, 0.85),
)

val STYLES = listOf(
    Style("Tanpa", 0.0, 0.0, 0.0, 0, 1.0, 1.0, 1.0, 1.0, 0.0, false),
    Style("Rapikan", 3.0, 1.0, 1.5, 3, 1.0, 1.0, 1.0, 1.0, 0.0, false),
    Style("Berita", 2.2, 2.0, 3.0, 3, 0.9, 1.03, 0.96, 0.97, 0.2, true),
    Style("Penyiar Radio", 4.0, 1.0, 2.0, 2, 0.95, 1.02, 0.92, 0.94, 0.45, true),
    Style("Pencerita Legenda", 5.0, 1.5, 3.0, 2, 1.5, 0.9, 0.93, 0.96, 0.25, false),
    Style("Presenter Semangat", 5.5, 0.0, 1.0, 2, 0.8, 1.08, 1.05, 1.0, 0.2, true),
)

object VoiceEngine {
    const val RATE = 44100
    const val MAX_MS = 10 * 60 * 1000L

    fun run(
        ctx: Context, uri: Uri, ch: Effect, st: Style, fmt: OutFmt, src: Int, nr: Int, br: Int, out: File,
        check: () -> Unit, onProgress: (String) -> Unit
    ): String {
        val dur = AudioDecoder.durationMs(ctx, uri)
        require(dur <= MAX_MS + 3000) { "Durasi maksimal 10 menit (file ini ${dur / 60000} mnt ${dur / 1000 % 60} dtk)" }
        onProgress("Membaca audio…")
        val pcm = AudioDecoder.decode(ctx, uri, RATE, (dur / 1000.0 * RATE).toInt() + RATE, check)
        require(pcm.isNotEmpty()) { "Audio kosong" }
        if (nr > 0) { onProgress("Membersihkan noise…"); Denoise.run(pcm, nr, check) }
        if (br > 0) { check(); onProgress("Mengurangi suara napas…"); Breath.run(pcm, RATE, br) }

        var res: FloatArray
        var info = if (nr > 0 || br > 0) "audio dibersihkan" else "tanpa perubahan"
        if (ch.isOriginal && st.isNone) {
            res = pcm
        } else {
            var pitchR = 1.0
            var formantR = 1.0
            if (ch.f0 > 0) {
                onProgress("Menganalisis nada suara…")
                val f0src = estimateF0(pcm)
                // 0 = laki-laki, 1 = perempuan, 2 = anak
                val kind = when (src) {
                    1 -> 0
                    2 -> 1
                    else -> if (f0src <= 0) 1 else if (f0src < 165) 0 else if (f0src < 255) 1 else 2
                }
                val srcFormant = doubleArrayOf(1.0, 1.17, 1.35)[kind]
                val f0ref = if (f0src > 0) f0src else doubleArrayOf(120.0, 205.0, 300.0)[kind]
                pitchR = (ch.f0 / f0ref).coerceIn(0.3, 3.5)
                formantR = ch.formant / srcFormant
                info = "sumber: ${listOf("laki-laki", "perempuan", "anak")[kind]} ±${f0src.toInt()} Hz"
            }
            val params = doubleArrayOf(
                pitchR * st.pitchMul, formantR * st.formantMul, ch.speed * st.speed,
                st.std, st.tilt, st.fall, maxOf(st.smooth, 2).toDouble(), st.pause
            )
            res = FloatArray(pcm.size + RATE * 5)
            var n = 0
            val cf = RATE / 100
            fun append(p: FloatArray) {
                if (n == 0) {
                    if (p.size > res.size) res = res.copyOf(p.size)
                    System.arraycopy(p, 0, res, 0, p.size); n = p.size; return
                }
                val c = min(cf, min(n, p.size))
                for (i in 0 until c) {
                    val a = i / c.toFloat()
                    res[n - c + i] = res[n - c + i] * (1 - a) + p[i] * a
                }
                if (n + p.size - c > res.size) res = res.copyOf(maxOf(res.size * 2, n + p.size))
                System.arraycopy(p, c, res, n, p.size - c)
                n += p.size - c
            }

            var s = 0
            while (s < pcm.size) {
                check()
                val rem = pcm.size - s
                // potong di titik paling sunyi supaya tidak terdengar sambungan
                val end = if (rem <= RATE * 23) pcm.size else quietPoint(pcm, s + RATE * 15, s + RATE * 22)
                onProgress("Memproses… ${100L * s / pcm.size}% • $info")
                val d = DoubleArray(end - s) { pcm[s + it].toDouble() }
                val y = NativeVoice.process(d, RATE, params)
                append(FloatArray(y.size) { y[it].toFloat() })
                s = end
            }
            res = res.copyOf(n)
            post(res, st.warm, st.comp)
        }
        normalize(res, 0.95f)
        check()
        onProgress("Menyimpan…")
        when (fmt) {
            OutFmt.WAV -> out.outputStream().use { writeWav(it, res, RATE) }
            OutFmt.M4A -> writeM4a(res, RATE, out)
        }
        return info
    }

    private fun estimateF0(pcm: FloatArray): Double {
        val w = RATE * 15
        val parts = if (pcm.size <= w * 3) listOf(0 to pcm.size)
        else listOf(0.1, 0.45, 0.8).map { val a = (pcm.size * it).toInt().coerceAtMost(pcm.size - w); a to a + w }
        val d = DoubleArray(parts.sumOf { it.second - it.first })
        var o = 0
        for ((a, b) in parts) for (i in a until b) d[o++] = pcm[i].toDouble()
        return NativeVoice.estimateF0(d, RATE)
    }

    private fun quietPoint(p: FloatArray, from: Int, to: Int): Int {
        var best = from; var bestE = Float.MAX_VALUE
        var i = from
        while (i + 480 < to) {
            var e = 0f
            for (k in i until i + 480) e += abs(p[k])
            if (e < bestE) { bestE = e; best = i + 240 }
            i += 240
        }
        return best
    }

    /** Warmth (low-shelf) + kompresor ala penyiar. */
    private fun post(x: FloatArray, warm: Double, comp: Boolean) {
        if (warm > 0) {
            val a = (1.0 - exp(-2.0 * PI * 200.0 / RATE)).toFloat()
            var lp = 0f
            for (i in x.indices) { lp += a * (x[i] - lp); x[i] += warm.toFloat() * lp }
        }
        if (comp) {
            normalize(x, 0.9f)
            val thr = 0.3f
            val att = exp(-1.0 / (0.005 * RATE)).toFloat()
            val rel = exp(-1.0 / (0.12 * RATE)).toFloat()
            var env = 0f
            for (i in x.indices) {
                val a = abs(x[i])
                env = if (a > env) att * env + (1 - att) * a else rel * env + (1 - rel) * a
                if (env > thr) x[i] *= (thr + (env - thr) / 3f) / env
            }
        }
    }

    private fun normalize(x: FloatArray, target: Float) {
        var peak = 0f
        for (v in x) peak = maxOf(peak, abs(v))
        if (peak <= 0f) return
        val g = target / peak
        for (i in x.indices) x[i] *= g
    }

    private fun writeWav(os: OutputStream, data: FloatArray, rate: Int) {
        val bytes = data.size * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + bytes).put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
        h.putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        h.put("data".toByteArray()).putInt(bytes)
        os.write(h.array())
        val body = ByteBuffer.allocate(bytes).order(ByteOrder.LITTLE_ENDIAN)
        for (v in data) body.putShort((v * 32767f).toInt().coerceIn(-32768, 32767).toShort())
        os.write(body.array())
    }

    private fun writeM4a(pcm: FloatArray, rate: Int, out: File) {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        val info = MediaCodec.BufferInfo()
        var pos = 0
        var inDone = false
        var outDone = false
        try {
            while (!outDone) {
                if (!inDone) {
                    val i = enc.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val b = enc.getInputBuffer(i)!!
                        b.clear(); b.order(ByteOrder.LITTLE_ENDIAN)
                        val n = min(b.capacity() / 2, pcm.size - pos)
                        val pts = pos * 1_000_000L / rate
                        if (n <= 0) {
                            enc.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            for (k in 0 until n) b.putShort((pcm[pos + k] * 32767f).toInt().coerceIn(-32768, 32767).toShort())
                            enc.queueInputBuffer(i, 0, n * 2, pts, 0)
                            pos += n
                        }
                    }
                }
                val o = enc.dequeueOutputBuffer(info, 10_000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.outputFormat)
                    mux.start(); started = true
                } else if (o >= 0) {
                    val b = enc.getOutputBuffer(o)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) {
                        b.position(info.offset); b.limit(info.offset + info.size)
                        mux.writeSampleData(track, b, info)
                    }
                    enc.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
        } finally {
            try { enc.stop() } catch (_: Throwable) {}
            enc.release()
            try { if (started) mux.stop() } catch (_: Throwable) {}
            mux.release()
        }
    }
}
